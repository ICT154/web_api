# A real example of Web Scraping with NodeJs and Cheerio

***How to run this project:***
- Clone or download this repository;
- Navigate to the project folder;
- Once in project folder, run ```yarn ``` or ```npm i``` if you are using npm;
- Then you can run this application in two ways:  
  - Run in dev mode with Nodemon```yarn dev``` or ```npm run dev```
  - Run in commom mode with Node```yarn start``` or ```npm start```

- Open [localhost:3000/deals](http://localhost:3000/deals) and see the results.
# api_web
